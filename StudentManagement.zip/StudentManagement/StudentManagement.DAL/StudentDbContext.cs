﻿using System.Data.Entity;
using StudentManagement.Entities;

namespace StudentManagement.DAL
{
    public class StudentDbContext : DbContext
    {
        public StudentDbContext() : base("name=StudentManagementConnection")
        {
            // Tắt lazy loading để tránh vấn đề khi serialize
            this.Configuration.LazyLoadingEnabled = false;
            this.Configuration.ProxyCreationEnabled = false;
        }

        public DbSet<Class> Classes { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Score> Scores { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Cấu hình Fluent API (tùy chọn, đã dùng Data Annotation)

            // Class
            modelBuilder.Entity<Class>()
                .HasKey(c => c.ClassId);

            // Student
            modelBuilder.Entity<Student>()
                .HasKey(s => s.StudentId);

            modelBuilder.Entity<Student>()
                .HasRequired(s => s.Class)
                .WithMany(c => c.Students)
                .HasForeignKey(s => s.ClassId)
                .WillCascadeOnDelete(true);

            // Subject
            modelBuilder.Entity<Subject>()
                .HasKey(sub => sub.SubjectId);

            // Score
            modelBuilder.Entity<Score>()
                .HasKey(sc => sc.ScoreId);

            modelBuilder.Entity<Score>()
                .HasRequired(sc => sc.Student)
                .WithMany(s => s.Scores)
                .HasForeignKey(sc => sc.StudentId)
                .WillCascadeOnDelete(true);

            modelBuilder.Entity<Score>()
                .HasRequired(sc => sc.Subject)
                .WithMany(sub => sub.Scores)
                .HasForeignKey(sc => sc.SubjectId)
                .WillCascadeOnDelete(true);
        }
    }
}