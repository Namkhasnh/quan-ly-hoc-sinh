﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using StudentManagement.Entities;

namespace StudentManagement.DAL.Repositories
{
    public interface ISubjectRepository
    {
        Task<List<Subject>> GetAllAsync();
        Task<Subject> GetByIdAsync(int id);
        Task<int> AddAsync(Subject subject);
        Task<bool> UpdateAsync(Subject subject);
        Task<bool> DeleteAsync(int id);
        Task<bool> ExistsByNameAsync(string subjectName);
    }

    public class SubjectRepository : ISubjectRepository
    {
        public async Task<List<Subject>> GetAllAsync()
        {
            using (var context = new StudentDbContext())
            {
                return await context.Subjects.ToListAsync();
            }
        }

        public async Task<Subject> GetByIdAsync(int id)
        {
            using (var context = new StudentDbContext())
            {
                return await context.Subjects
                    .Include(s => s.Scores)
                    .FirstOrDefaultAsync(s => s.SubjectId == id);
            }
        }

        public async Task<int> AddAsync(Subject subject)
        {
            if (subject == null)
                throw new ArgumentNullException(nameof(subject));

            using (var context = new StudentDbContext())
            {
                context.Subjects.Add(subject);
                await context.SaveChangesAsync();
                return subject.SubjectId;
            }
        }

        public async Task<bool> UpdateAsync(Subject subject)
        {
            if (subject == null)
                throw new ArgumentNullException(nameof(subject));

            using (var context = new StudentDbContext())
            {
                var existing = await context.Subjects.FindAsync(subject.SubjectId);
                if (existing == null)
                    return false;

                context.Entry(existing).CurrentValues.SetValues(subject);
                await context.SaveChangesAsync();
                return true;
            }
        }

        public async Task<bool> DeleteAsync(int id)
        {
            using (var context = new StudentDbContext())
            {
                var subject = await context.Subjects.FindAsync(id);
                if (subject == null)
                    return false;

                context.Subjects.Remove(subject);
                await context.SaveChangesAsync();
                return true;
            }
        }

        public async Task<bool> ExistsByNameAsync(string subjectName)
        {
            using (var context = new StudentDbContext())
            {
                return await context.Subjects
                    .AnyAsync(s => s.SubjectName == subjectName);
            }
        }
    }
}