﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using StudentManagement.Entities;

namespace StudentManagement.DAL.Repositories
{
    public interface IStudentRepository
    {
        Task<List<Student>> GetAllAsync();
        Task<Student> GetByIdAsync(int id);
        Task<List<Student>> GetByClassIdAsync(int classId);
        Task<List<Student>> SearchByNameAsync(string name);
        Task<int> AddAsync(Student student);
        Task<bool> UpdateAsync(Student student);
        Task<bool> DeleteAsync(int id);
        Task<int> CountAsync();
    }

    public class StudentRepository : IStudentRepository
    {
        public async Task<List<Student>> GetAllAsync()
        {
            using (var context = new StudentDbContext())
            {
                return await context.Students
                    .Include(s => s.Class)
                    .Include(s => s.Scores)
                    .ToListAsync();
            }
        }

        public async Task<Student> GetByIdAsync(int id)
        {
            using (var context = new StudentDbContext())
            {
                return await context.Students
                    .Include(s => s.Class)
                    .Include(s => s.Scores)
                    .FirstOrDefaultAsync(s => s.StudentId == id);
            }
        }

        public async Task<List<Student>> GetByClassIdAsync(int classId)
        {
            using (var context = new StudentDbContext())
            {
                return await context.Students
                    .Include(s => s.Class)
                    .Include(s => s.Scores)
                    .Where(s => s.ClassId == classId)
                    .ToListAsync();
            }
        }

        public async Task<List<Student>> SearchByNameAsync(string name)
        {
            using (var context = new StudentDbContext())
            {
                if (string.IsNullOrWhiteSpace(name))
                {
                    return await GetAllAsync();
                }

                return await context.Students
                    .Include(s => s.Class)
                    .Where(s => s.StudentName.Contains(name))
                    .ToListAsync();
            }
        }

        public async Task<int> AddAsync(Student student)
        {
            if (student == null)
                throw new ArgumentNullException(nameof(student));

            using (var context = new StudentDbContext())
            {
                context.Students.Add(student);
                await context.SaveChangesAsync();
                return student.StudentId;
            }
        }

        public async Task<bool> UpdateAsync(Student student)
        {
            if (student == null)
                throw new ArgumentNullException(nameof(student));

            using (var context = new StudentDbContext())
            {
                var existing = await context.Students.FindAsync(student.StudentId);
                if (existing == null)
                    return false;

                context.Entry(existing).CurrentValues.SetValues(student);
                await context.SaveChangesAsync();
                return true;
            }
        }

        public async Task<bool> DeleteAsync(int id)
        {
            using (var context = new StudentDbContext())
            {
                var student = await context.Students.FindAsync(id);
                if (student == null)
                    return false;

                context.Students.Remove(student);
                await context.SaveChangesAsync();
                return true;
            }
        }

        public async Task<int> CountAsync()
        {
            using (var context = new StudentDbContext())
            {
                return await context.Students.CountAsync();
            }
        }
    }
}