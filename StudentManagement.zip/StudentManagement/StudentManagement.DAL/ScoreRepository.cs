﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using StudentManagement.Entities;

namespace StudentManagement.DAL.Repositories
{
    public interface IScoreRepository
    {
        Task<List<Score>> GetAllAsync();
        Task<Score> GetByIdAsync(int id);
        Task<List<Score>> GetByStudentIdAsync(int studentId);
        Task<List<Score>> GetBySubjectIdAsync(int subjectId);
        Task<int> AddAsync(Score score);
        Task<bool> UpdateAsync(Score score);
        Task<bool> DeleteAsync(int id);
        Task<bool> AddRangeWithTransactionAsync(List<Score> scores);
        Task<Score> GetByStudentAndSubjectAsync(int studentId, int subjectId);
    }

    public class ScoreRepository : IScoreRepository
    {
        public async Task<List<Score>> GetAllAsync()
        {
            using (var context = new StudentDbContext())
            {
                return await context.Scores
                    .Include(s => s.Student)
                    .Include(s => s.Subject)
                    .ToListAsync();
            }
        }

        public async Task<Score> GetByIdAsync(int id)
        {
            using (var context = new StudentDbContext())
            {
                return await context.Scores
                    .Include(s => s.Student)
                    .Include(s => s.Subject)
                    .FirstOrDefaultAsync(s => s.ScoreId == id);
            }
        }

        public async Task<List<Score>> GetByStudentIdAsync(int studentId)
        {
            using (var context = new StudentDbContext())
            {
                return await context.Scores
                    .Include(s => s.Student)
                    .Include(s => s.Subject)
                    .Where(s => s.StudentId == studentId)
                    .ToListAsync();
            }
        }

        public async Task<List<Score>> GetBySubjectIdAsync(int subjectId)
        {
            using (var context = new StudentDbContext())
            {
                return await context.Scores
                    .Include(s => s.Student)
                    .Include(s => s.Subject)
                    .Where(s => s.SubjectId == subjectId)
                    .ToListAsync();
            }
        }

        public async Task<Score> GetByStudentAndSubjectAsync(int studentId, int subjectId)
        {
            using (var context = new StudentDbContext())
            {
                return await context.Scores
                    .FirstOrDefaultAsync(s =>
                        s.StudentId == studentId &&
                        s.SubjectId == subjectId);
            }
        }

        public async Task<int> AddAsync(Score score)
        {
            if (score == null)
                throw new ArgumentNullException(nameof(score));

            using (var context = new StudentDbContext())
            {
                context.Scores.Add(score);
                await context.SaveChangesAsync();
                return score.ScoreId;
            }
        }

        public async Task<bool> UpdateAsync(Score score)
        {
            if (score == null)
                throw new ArgumentNullException(nameof(score));

            using (var context = new StudentDbContext())
            {
                var existing = await context.Scores.FindAsync(score.ScoreId);
                if (existing == null)
                    return false;

                context.Entry(existing).CurrentValues.SetValues(score);
                await context.SaveChangesAsync();
                return true;
            }
        }

        public async Task<bool> DeleteAsync(int id)
        {
            using (var context = new StudentDbContext())
            {
                var score = await context.Scores.FindAsync(id);
                if (score == null)
                    return false;

                context.Scores.Remove(score);
                await context.SaveChangesAsync();
                return true;
            }
        }

        // ✅ TRANSACTION ĐÚNG CÁCH
        public async Task<bool> AddRangeWithTransactionAsync(List<Score> scores)
        {
            if (scores == null || !scores.Any())
                return false;

            using (var context = new StudentDbContext())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    context.Scores.AddRange(scores);
                    await context.SaveChangesAsync();

                    transaction.Commit();
                    return true;
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
    }
}