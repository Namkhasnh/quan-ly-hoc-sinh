﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using StudentManagement.Entities;

namespace StudentManagement.DAL.Repositories
{
    public interface IClassRepository
    {
        Task<List<Class>> GetAllAsync();
        Task<Class> GetByIdAsync(int id);
        Task<int> AddAsync(Class classEntity);
        Task<bool> UpdateAsync(Class classEntity);
        Task<bool> DeleteAsync(int id);
        Task<bool> ExistsByNameAsync(string className);
    }

    public class ClassRepository : IClassRepository
    {
        public async Task<List<Class>> GetAllAsync()
        {
            using (var context = new StudentDbContext())
            {
                return await context.Classes
                    .Include(c => c.Students)
                    .ToListAsync();
            }
        }

        public async Task<Class> GetByIdAsync(int id)
        {
            using (var context = new StudentDbContext())
            {
                return await context.Classes
                    .Include(c => c.Students)
                    .FirstOrDefaultAsync(c => c.ClassId == id);
            }
        }

        public async Task<int> AddAsync(Class classEntity)
        {
            if (classEntity == null)
                throw new ArgumentNullException(nameof(classEntity));

            using (var context = new StudentDbContext())
            {
                context.Classes.Add(classEntity);
                await context.SaveChangesAsync();
                return classEntity.ClassId;
            }
        }

        public async Task<bool> UpdateAsync(Class classEntity)
        {
            if (classEntity == null)
                throw new ArgumentNullException(nameof(classEntity));

            using (var context = new StudentDbContext())
            {
                var existing = await context.Classes.FindAsync(classEntity.ClassId);
                if (existing == null)
                    return false;

                context.Entry(existing).CurrentValues.SetValues(classEntity);
                await context.SaveChangesAsync();
                return true;
            }
        }

        public async Task<bool> DeleteAsync(int id)
        {
            using (var context = new StudentDbContext())
            {
                var classEntity = await context.Classes.FindAsync(id);
                if (classEntity == null)
                    return false;

                context.Classes.Remove(classEntity);
                await context.SaveChangesAsync();
                return true;
            }
        }

        public async Task<bool> ExistsByNameAsync(string className)
        {
            using (var context = new StudentDbContext())
            {
                return await context.Classes
                    .AnyAsync(c => c.ClassName == className);
            }
        }
    }
}