﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StudentManagement.DAL.Repositories;

namespace StudentManagement.BLL.Services
{
    // DTO cho báo cáo thống kê lớp
    public class ClassStatisticsDto
    {
        public int ClassId { get; set; }
        public string ClassName { get; set; }
        public int TotalStudents { get; set; }
        public decimal AverageScore { get; set; }
    }

    // DTO cho báo cáo sinh viên
    public class StudentReportDto
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public string ClassName { get; set; }
        public decimal AverageScore { get; set; }
        public int TotalSubjects { get; set; }
        public string Rank { get; set; }
    }

    public interface IReportService
    {
        Task<List<ClassStatisticsDto>> GetClassStatisticsAsync();
        Task<List<StudentReportDto>> GetStudentReportByClassAsync(int classId);
        Task<List<StudentReportDto>> GetTopStudentsAsync(int topCount);
        Task<List<StudentReportDto>> GetStudentsByAverageScoreRangeAsync(decimal minScore, decimal maxScore);
    }

    public class ReportService : IReportService
    {
        private readonly IStudentRepository _studentRepo;
        private readonly IScoreRepository _scoreRepo;
        private readonly IClassRepository _classRepo;

        public ReportService(
            IStudentRepository studentRepo,
            IScoreRepository scoreRepo,
            IClassRepository classRepo)
        {
            _studentRepo = studentRepo ?? throw new ArgumentNullException(nameof(studentRepo));
            _scoreRepo = scoreRepo ?? throw new ArgumentNullException(nameof(scoreRepo));
            _classRepo = classRepo ?? throw new ArgumentNullException(nameof(classRepo));
        }

        // THỐNG KÊ THEO LỚP
        public async Task<List<ClassStatisticsDto>> GetClassStatisticsAsync()
        {
            var classes = await _classRepo.GetAllAsync();
            var result = new List<ClassStatisticsDto>();

            foreach (var c in classes)
            {
                var students = await _studentRepo.GetByClassIdAsync(c.ClassId);
                var totalStudents = students.Count;

                decimal totalAvg = 0;
                foreach (var student in students)
                {
                    var scores = await _scoreRepo.GetByStudentIdAsync(student.StudentId);
                    if (scores.Any())
                    {
                        totalAvg += scores.Average(s => s.ScoreValue);
                    }
                }

                result.Add(new ClassStatisticsDto
                {
                    ClassId = c.ClassId,
                    ClassName = c.ClassName,
                    TotalStudents = totalStudents,
                    AverageScore = totalStudents > 0 ? Math.Round(totalAvg / totalStudents, 2) : 0
                });
            }

            return result;
        }

        // BÁO CÁO SINH VIÊN THEO LỚP
        public async Task<List<StudentReportDto>> GetStudentReportByClassAsync(int classId)
        {
            if (classId <= 0)
                throw new ArgumentException("ID lớp không hợp lệ", nameof(classId));

            var students = await _studentRepo.GetByClassIdAsync(classId);
            var result = new List<StudentReportDto>();

            foreach (var student in students)
            {
                var scores = await _scoreRepo.GetByStudentIdAsync(student.StudentId);
                var avgScore = scores.Any() ? scores.Average(s => s.ScoreValue) : 0;

                result.Add(new StudentReportDto
                {
                    StudentId = student.StudentId,
                    StudentName = student.StudentName,
                    ClassName = student.Class?.ClassName ?? "",
                    AverageScore = Math.Round(avgScore, 2),
                    TotalSubjects = scores.Count,
                    Rank = GetRank(avgScore)
                });
            }

            return result.OrderByDescending(r => r.AverageScore).ToList();
        }

        // TOP SINH VIÊN GIỎI NHẤT
        public async Task<List<StudentReportDto>> GetTopStudentsAsync(int topCount)
        {
            if (topCount <= 0)
                topCount = 10;

            var allStudents = await _studentRepo.GetAllAsync();
            var result = new List<StudentReportDto>();

            foreach (var student in allStudents)
            {
                var scores = await _scoreRepo.GetByStudentIdAsync(student.StudentId);
                if (!scores.Any())
                    continue;

                var avgScore = scores.Average(s => s.ScoreValue);

                result.Add(new StudentReportDto
                {
                    StudentId = student.StudentId,
                    StudentName = student.StudentName,
                    ClassName = student.Class?.ClassName ?? "",
                    AverageScore = Math.Round(avgScore, 2),
                    TotalSubjects = scores.Count,
                    Rank = GetRank(avgScore)
                });
            }

            return result.OrderByDescending(r => r.AverageScore).Take(topCount).ToList();
        }

        // SINH VIÊN THEO KHOẢNG ĐIỂM
        public async Task<List<StudentReportDto>> GetStudentsByAverageScoreRangeAsync(decimal minScore, decimal maxScore)
        {
            if (minScore < 0 || maxScore > 10 || minScore > maxScore)
                throw new ArgumentException("Khoảng điểm không hợp lệ");

            var allStudents = await _studentRepo.GetAllAsync();
            var result = new List<StudentReportDto>();

            foreach (var student in allStudents)
            {
                var scores = await _scoreRepo.GetByStudentIdAsync(student.StudentId);
                if (!scores.Any())
                    continue;

                var avgScore = scores.Average(s => s.ScoreValue);

                if (avgScore >= minScore && avgScore <= maxScore)
                {
                    result.Add(new StudentReportDto
                    {
                        StudentId = student.StudentId,
                        StudentName = student.StudentName,
                        ClassName = student.Class?.ClassName ?? "",
                        AverageScore = Math.Round(avgScore, 2),
                        TotalSubjects = scores.Count,
                        Rank = GetRank(avgScore)
                    });
                }
            }

            return result.OrderByDescending(r => r.AverageScore).ToList();
        }

        // XẾP LOẠI HỌC LỰC
        private string GetRank(decimal avgScore)
        {
            if (avgScore >= 8.5m) return "Xuất sắc";
            if (avgScore >= 7.0m) return "Giỏi";
            if (avgScore >= 5.5m) return "Khá";
            if (avgScore >= 4.0m) return "Trung bình";
            return "Yếu";
        }
    }
}