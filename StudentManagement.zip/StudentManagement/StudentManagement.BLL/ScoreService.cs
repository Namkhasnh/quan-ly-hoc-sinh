﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StudentManagement.DAL.Repositories;
using StudentManagement.Entities;

namespace StudentManagement.BLL.Services
{
    public interface IScoreService
    {
        Task<List<Score>> GetAllScoresAsync();
        Task<Score> GetScoreByIdAsync(int id);
        Task<List<Score>> GetScoresByStudentIdAsync(int studentId);
        Task<List<Score>> GetScoresBySubjectIdAsync(int subjectId);
        Task<int> AddScoreAsync(Score score);
        Task<bool> UpdateScoreAsync(Score score);
        Task<bool> DeleteScoreAsync(int id);
        Task<bool> AddMultipleScoresAsync(List<Score> scores);
        Task<decimal> GetAverageScoreByStudentAsync(int studentId);
    }

    public class ScoreService : IScoreService
    {
        private readonly IScoreRepository _scoreRepo;
        private readonly IStudentRepository _studentRepo;
        private readonly ISubjectRepository _subjectRepo;

        public ScoreService(
            IScoreRepository scoreRepo,
            IStudentRepository studentRepo,
            ISubjectRepository subjectRepo)
        {
            _scoreRepo = scoreRepo ?? throw new ArgumentNullException(nameof(scoreRepo));
            _studentRepo = studentRepo ?? throw new ArgumentNullException(nameof(studentRepo));
            _subjectRepo = subjectRepo ?? throw new ArgumentNullException(nameof(subjectRepo));
        }

        public async Task<List<Score>> GetAllScoresAsync()
        {
            return await _scoreRepo.GetAllAsync();
        }

        public async Task<Score> GetScoreByIdAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("ID điểm phải lớn hơn 0", nameof(id));

            return await _scoreRepo.GetByIdAsync(id);
        }

        public async Task<List<Score>> GetScoresByStudentIdAsync(int studentId)
        {
            if (studentId <= 0)
                throw new ArgumentException("ID sinh viên không hợp lệ", nameof(studentId));

            return await _scoreRepo.GetByStudentIdAsync(studentId);
        }

        public async Task<List<Score>> GetScoresBySubjectIdAsync(int subjectId)
        {
            if (subjectId <= 0)
                throw new ArgumentException("ID môn học không hợp lệ", nameof(subjectId));

            return await _scoreRepo.GetBySubjectIdAsync(subjectId);
        }

        public async Task<int> AddScoreAsync(Score score)
        {
            await ValidateScoreAsync(score);

            // Kiểm tra xem sinh viên đã có điểm môn này chưa
            var existing = await _scoreRepo.GetByStudentAndSubjectAsync(score.StudentId, score.SubjectId);
            if (existing != null)
                throw new InvalidOperationException("Sinh viên đã có điểm môn học này");

            return await _scoreRepo.AddAsync(score);
        }

        public async Task<bool> UpdateScoreAsync(Score score)
        {
            await ValidateScoreAsync(score);

            if (score.ScoreId <= 0)
                throw new ArgumentException("ID điểm không hợp lệ");

            return await _scoreRepo.UpdateAsync(score);
        }

        public async Task<bool> DeleteScoreAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("ID điểm phải lớn hơn 0", nameof(id));

            return await _scoreRepo.DeleteAsync(id);
        }

        // VÍ DỤ SỬ DỤNG TRANSACTION: Thêm nhiều điểm cùng lúc
        public async Task<bool> AddMultipleScoresAsync(List<Score> scores)
        {
            if (scores == null || !scores.Any())
                throw new ArgumentException("Danh sách điểm không được rỗng");

            // Validate tất cả điểm trước khi thêm
            foreach (var score in scores)
            {
                await ValidateScoreAsync(score);
            }

            return await _scoreRepo.AddRangeWithTransactionAsync(scores);
        }

        public async Task<decimal> GetAverageScoreByStudentAsync(int studentId)
        {
            if (studentId <= 0)
                throw new ArgumentException("ID sinh viên không hợp lệ", nameof(studentId));

            var scores = await _scoreRepo.GetByStudentIdAsync(studentId);

            if (!scores.Any())
                return 0;

            return scores.Average(s => s.ScoreValue);
        }

        private async Task ValidateScoreAsync(Score score)
        {
            if (score == null)
                throw new ArgumentNullException(nameof(score));

            if (score.StudentId <= 0)
                throw new ArgumentException("ID sinh viên không hợp lệ");

            if (score.SubjectId <= 0)
                throw new ArgumentException("ID môn học không hợp lệ");

            if (score.ScoreValue < 0 || score.ScoreValue > 10)
                throw new ArgumentException("Điểm phải nằm trong khoảng 0-10");

            // Kiểm tra sinh viên có tồn tại không
            var student = await _studentRepo.GetByIdAsync(score.StudentId);
            if (student == null)
                throw new InvalidOperationException("Sinh viên không tồn tại");

            // Kiểm tra môn học có tồn tại không
            var subject = await _subjectRepo.GetByIdAsync(score.SubjectId);
            if (subject == null)
                throw new InvalidOperationException("Môn học không tồn tại");
        }
    }
}