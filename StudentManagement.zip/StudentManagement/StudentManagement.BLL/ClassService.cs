﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using StudentManagement.DAL.Repositories;
using StudentManagement.Entities;

namespace StudentManagement.BLL.Services
{
    public interface IClassService
    {
        Task<List<Class>> GetAllClassesAsync();
        Task<Class> GetClassByIdAsync(int id);
        Task<int> AddClassAsync(Class classEntity);
        Task<bool> UpdateClassAsync(Class classEntity);
        Task<bool> DeleteClassAsync(int id);
        Task<int> GetStudentCountByClassAsync(int classId);
    }

    public class ClassService : IClassService
    {
        private readonly IClassRepository _classRepo;

        public ClassService(IClassRepository classRepo)
        {
            _classRepo = classRepo ?? throw new ArgumentNullException(nameof(classRepo));
        }

        public async Task<List<Class>> GetAllClassesAsync()
        {
            return await _classRepo.GetAllAsync();
        }

        public async Task<Class> GetClassByIdAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("ID lớp phải lớn hơn 0", nameof(id));

            return await _classRepo.GetByIdAsync(id);
        }

        public async Task<int> AddClassAsync(Class classEntity)
        {
            ValidateClass(classEntity);

            // Kiểm tra trùng tên lớp
            if (await _classRepo.ExistsByNameAsync(classEntity.ClassName))
                throw new InvalidOperationException($"Lớp '{classEntity.ClassName}' đã tồn tại");

            return await _classRepo.AddAsync(classEntity);
        }

        public async Task<bool> UpdateClassAsync(Class classEntity)
        {
            ValidateClass(classEntity);

            if (classEntity.ClassId <= 0)
                throw new ArgumentException("ID lớp không hợp lệ");

            return await _classRepo.UpdateAsync(classEntity);
        }

        public async Task<bool> DeleteClassAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("ID lớp phải lớn hơn 0", nameof(id));

            // Kiểm tra xem lớp có sinh viên không
            var classEntity = await _classRepo.GetByIdAsync(id);
            if (classEntity != null && classEntity.Students.Count > 0)
                throw new InvalidOperationException("Không thể xóa lớp vì còn sinh viên");

            return await _classRepo.DeleteAsync(id);
        }

        public async Task<int> GetStudentCountByClassAsync(int classId)
        {
            if (classId <= 0)
                throw new ArgumentException("ID lớp không hợp lệ", nameof(classId));

            var classEntity = await _classRepo.GetByIdAsync(classId);
            return classEntity?.Students.Count ?? 0;
        }

        private void ValidateClass(Class classEntity)
        {
            if (classEntity == null)
                throw new ArgumentNullException(nameof(classEntity));

            if (string.IsNullOrWhiteSpace(classEntity.ClassName))
                throw new ArgumentException("Tên lớp không được để trống");
        }
    }
}