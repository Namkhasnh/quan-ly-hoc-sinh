﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using StudentManagement.DAL.Repositories;
using StudentManagement.Entities;

namespace StudentManagement.BLL.Services
{
    public interface ISubjectService
    {
        Task<List<Subject>> GetAllSubjectsAsync();
        Task<Subject> GetSubjectByIdAsync(int id);
        Task<int> AddSubjectAsync(Subject subject);
        Task<bool> UpdateSubjectAsync(Subject subject);
        Task<bool> DeleteSubjectAsync(int id);
    }

    public class SubjectService : ISubjectService
    {
        private readonly ISubjectRepository _subjectRepo;

        public SubjectService(ISubjectRepository subjectRepo)
        {
            _subjectRepo = subjectRepo ?? throw new ArgumentNullException(nameof(subjectRepo));
        }

        public async Task<List<Subject>> GetAllSubjectsAsync()
        {
            return await _subjectRepo.GetAllAsync();
        }

        public async Task<Subject> GetSubjectByIdAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("ID môn học phải lớn hơn 0", nameof(id));

            return await _subjectRepo.GetByIdAsync(id);
        }

        public async Task<int> AddSubjectAsync(Subject subject)
        {
            ValidateSubject(subject);

            // Kiểm tra trùng tên môn học
            if (await _subjectRepo.ExistsByNameAsync(subject.SubjectName))
                throw new InvalidOperationException($"Môn học '{subject.SubjectName}' đã tồn tại");

            return await _subjectRepo.AddAsync(subject);
        }

        public async Task<bool> UpdateSubjectAsync(Subject subject)
        {
            ValidateSubject(subject);

            if (subject.SubjectId <= 0)
                throw new ArgumentException("ID môn học không hợp lệ");

            return await _subjectRepo.UpdateAsync(subject);
        }

        public async Task<bool> DeleteSubjectAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("ID môn học phải lớn hơn 0", nameof(id));

            return await _subjectRepo.DeleteAsync(id);
        }

        private void ValidateSubject(Subject subject)
        {
            if (subject == null)
                throw new ArgumentNullException(nameof(subject));

            if (string.IsNullOrWhiteSpace(subject.SubjectName))
                throw new ArgumentException("Tên môn học không được để trống");

            if (subject.Credit <= 0)
                throw new ArgumentException("Số tín chỉ phải lớn hơn 0");
        }
    }
}