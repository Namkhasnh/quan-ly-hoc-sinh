﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StudentManagement.DAL.Repositories;
using StudentManagement.Entities;

namespace StudentManagement.BLL.Services
{
    public interface IStudentService
    {
        Task<List<Student>> GetAllStudentsAsync();
        Task<Student> GetStudentByIdAsync(int id);
        Task<List<Student>> GetStudentsByClassAsync(int classId);
        Task<List<Student>> SearchStudentsByNameAsync(string name);
        Task<int> AddStudentAsync(Student student);
        Task<bool> UpdateStudentAsync(Student student);
        Task<bool> DeleteStudentAsync(int id);
        Task<int> GetTotalStudentsAsync();
        Task<decimal> CalculateAverageScoreAsync(int studentId);
    }

    public class StudentService : IStudentService
    {
        private readonly IStudentRepository _studentRepo;
        private readonly IScoreRepository _scoreRepo;

        public StudentService(IStudentRepository studentRepo, IScoreRepository scoreRepo)
        {
            _studentRepo = studentRepo ?? throw new ArgumentNullException(nameof(studentRepo));
            _scoreRepo = scoreRepo ?? throw new ArgumentNullException(nameof(scoreRepo));
        }

        public async Task<List<Student>> GetAllStudentsAsync()
        {
            return await _studentRepo.GetAllAsync();
        }

        public async Task<Student> GetStudentByIdAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("ID phải lớn hơn 0", nameof(id));

            return await _studentRepo.GetByIdAsync(id);
        }

        public async Task<List<Student>> GetStudentsByClassAsync(int classId)
        {
            if (classId <= 0)
                throw new ArgumentException("ID lớp phải lớn hơn 0", nameof(classId));

            return await _studentRepo.GetByClassIdAsync(classId);
        }

        public async Task<List<Student>> SearchStudentsByNameAsync(string name)
        {
            return await _studentRepo.SearchByNameAsync(name);
        }

        public async Task<int> AddStudentAsync(Student student)
        {
            // Kiểm tra dữ liệu đầu vào
            ValidateStudent(student);

            // Kiểm tra tuổi hợp lệ (>= 16 tuổi)
            var age = DateTime.Now.Year - student.DateOfBirth.Year;
            if (age < 16)
                throw new InvalidOperationException("Sinh viên phải từ 16 tuổi trở lên");

            return await _studentRepo.AddAsync(student);
        }

        public async Task<bool> UpdateStudentAsync(Student student)
        {
            ValidateStudent(student);

            if (student.StudentId <= 0)
                throw new ArgumentException("ID sinh viên không hợp lệ");

            return await _studentRepo.UpdateAsync(student);
        }

        public async Task<bool> DeleteStudentAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("ID phải lớn hơn 0", nameof(id));

            return await _studentRepo.DeleteAsync(id);
        }

        public async Task<int> GetTotalStudentsAsync()
        {
            return await _studentRepo.CountAsync();
        }

        // TÍNH ĐIỂM TRUNG BÌNH CỦA SINH VIÊN
        public async Task<decimal> CalculateAverageScoreAsync(int studentId)
        {
            if (studentId <= 0)
                throw new ArgumentException("ID sinh viên không hợp lệ", nameof(studentId));

            var scores = await _scoreRepo.GetByStudentIdAsync(studentId);

            if (!scores.Any())
                return 0;

            return scores.Average(s => s.ScoreValue);
        }

        // VALIDATE STUDENT
        private void ValidateStudent(Student student)
        {
            if (student == null)
                throw new ArgumentNullException(nameof(student));

            if (string.IsNullOrWhiteSpace(student.StudentName))
                throw new ArgumentException("Tên sinh viên không được để trống");

            if (student.DateOfBirth > DateTime.Now)
                throw new ArgumentException("Ngày sinh không hợp lệ");

            if (string.IsNullOrWhiteSpace(student.Gender))
                throw new ArgumentException("Giới tính không được để trống");

            if (student.ClassId <= 0)
                throw new ArgumentException("Lớp học không hợp lệ");
        }
    }
}