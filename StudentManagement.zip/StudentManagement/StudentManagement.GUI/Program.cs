﻿using System;
using System.Windows.Forms;
using Microsoft.Extensions.DependencyInjection;
using StudentManagement.BLL.Services;
using StudentManagement.DAL;
using StudentManagement.DAL.Repositories;
using StudentManagement.GUI.Forms;

namespace StudentManagement.GUI
{
    static class Program
    {
        public static IServiceProvider ServiceProvider { get; private set; }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Cấu hình Dependency Injection
            var services = new ServiceCollection();
            ConfigureServices(services);
            ServiceProvider = services.BuildServiceProvider();

            // Khởi chạy MainForm với DI
            var mainForm = ServiceProvider.GetRequiredService<MainForm>();
            Application.Run(mainForm);
        }

        private static void ConfigureServices(IServiceCollection services)
        {
            // 1. Đăng ký DbContext
            services.AddTransient<StudentDbContext>();

            // 2. Đăng ký Repositories (DAL)
            services.AddTransient<IStudentRepository, StudentRepository>();
            services.AddTransient<IClassRepository, ClassRepository>();
            services.AddTransient<ISubjectRepository, SubjectRepository>();
            services.AddTransient<IScoreRepository, ScoreRepository>();

            // 3. Đăng ký Services (BLL)
            services.AddTransient<IStudentService, StudentService>();
            services.AddTransient<IClassService, ClassService>();
            services.AddTransient<ISubjectService, SubjectService>();
            services.AddTransient<IScoreService, ScoreService>();
            services.AddTransient<IReportService, ReportService>();

            // 4. Đăng ký Forms
            services.AddTransient<MainForm>();
            services.AddTransient<StudentForm>();
            services.AddTransient<ClassForm>();
            services.AddTransient<SubjectForm>();
            services.AddTransient<ScoreForm>();
            services.AddTransient<ReportForm>();
        }
    }
}