﻿using System;

namespace StudentManagement.GUI.Forms
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbClass = new System.Windows.Forms.ComboBox();
            this.txtMaxScore = new System.Windows.Forms.TextBox();
            this.txtTopCount = new System.Windows.Forms.TextBox();
            this.txtMinScore = new System.Windows.Forms.TextBox();
            this.btnClassStatistics = new System.Windows.Forms.Button();
            this.btnStudentsByClass = new System.Windows.Forms.Button();
            this.btnTopStudents = new System.Windows.Forms.Button();
            this.btnScoreRange = new System.Windows.Forms.Button();
            this.dgvReport = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).BeginInit();
            this.SuspendLayout();
            // 
            // cbClass
            // 
            this.cbClass.FormattingEnabled = true;
            this.cbClass.Location = new System.Drawing.Point(170, 49);
            this.cbClass.Name = "cbClass";
            this.cbClass.Size = new System.Drawing.Size(143, 44);
            this.cbClass.TabIndex = 0;
            // 
            // txtMaxScore
            // 
            this.txtMaxScore.Location = new System.Drawing.Point(938, 49);
            this.txtMaxScore.Name = "txtMaxScore";
            this.txtMaxScore.Size = new System.Drawing.Size(153, 44);
            this.txtMaxScore.TabIndex = 1;
            // 
            // txtTopCount
            // 
            this.txtTopCount.Location = new System.Drawing.Point(426, 49);
            this.txtTopCount.Name = "txtTopCount";
            this.txtTopCount.Size = new System.Drawing.Size(97, 44);
            this.txtTopCount.TabIndex = 2;
            // 
            // txtMinScore
            // 
            this.txtMinScore.Location = new System.Drawing.Point(682, 49);
            this.txtMinScore.Name = "txtMinScore";
            this.txtMinScore.Size = new System.Drawing.Size(155, 44);
            this.txtMinScore.TabIndex = 3;
            // 
            // btnClassStatistics
            // 
            this.btnClassStatistics.Location = new System.Drawing.Point(190, 111);
            this.btnClassStatistics.Name = "btnClassStatistics";
            this.btnClassStatistics.Size = new System.Drawing.Size(162, 57);
            this.btnClassStatistics.TabIndex = 4;
            this.btnClassStatistics.Text = "Thong ke theo lop";
            this.btnClassStatistics.UseVisualStyleBackColor = true;
            this.btnClassStatistics.Click += new System.EventHandler(this.BtnClassStatistics_Click);
            // 
            // btnStudentsByClass
            // 
            this.btnStudentsByClass.Location = new System.Drawing.Point(418, 111);
            this.btnStudentsByClass.Name = "btnStudentsByClass";
            this.btnStudentsByClass.Size = new System.Drawing.Size(197, 57);
            this.btnStudentsByClass.TabIndex = 5;
            this.btnStudentsByClass.Text = "Sinh vien theo lop";
            this.btnStudentsByClass.UseVisualStyleBackColor = true;
            this.btnStudentsByClass.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnTopStudents
            // 
            this.btnTopStudents.Location = new System.Drawing.Point(646, 111);
            this.btnTopStudents.Name = "btnTopStudents";
            this.btnTopStudents.Size = new System.Drawing.Size(191, 57);
            this.btnTopStudents.TabIndex = 6;
            this.btnTopStudents.Text = "Top sinh vien gioi ";
            this.btnTopStudents.UseVisualStyleBackColor = true;
            // 
            // btnScoreRange
            // 
            this.btnScoreRange.Location = new System.Drawing.Point(903, 111);
            this.btnScoreRange.Name = "btnScoreRange";
            this.btnScoreRange.Size = new System.Drawing.Size(191, 57);
            this.btnScoreRange.TabIndex = 7;
            this.btnScoreRange.Text = "Theo khoang diem";
            this.btnScoreRange.UseVisualStyleBackColor = true;
            // 
            // dgvReport
            // 
            this.dgvReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReport.Location = new System.Drawing.Point(12, 200);
            this.dgvReport.Name = "dgvReport";
            this.dgvReport.RowHeadersWidth = 82;
            this.dgvReport.RowTemplate.Height = 33;
            this.dgvReport.Size = new System.Drawing.Size(1183, 512);
            this.dgvReport.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(77, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 36);
            this.label1.TabIndex = 9;
            this.label1.Text = "Chon lop";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(346, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 36);
            this.label2.TabIndex = 10;
            this.label2.Text = "Top";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(583, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 36);
            this.label3.TabIndex = 11;
            this.label3.Text = "Diem tu";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(843, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 36);
            this.label4.TabIndex = 12;
            this.label4.Text = "Diem den";
            // 
            // ReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(18F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1207, 724);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvReport);
            this.Controls.Add(this.btnScoreRange);
            this.Controls.Add(this.btnTopStudents);
            this.Controls.Add(this.btnStudentsByClass);
            this.Controls.Add(this.btnClassStatistics);
            this.Controls.Add(this.txtMinScore);
            this.Controls.Add(this.txtTopCount);
            this.Controls.Add(this.txtMaxScore);
            this.Controls.Add(this.cbClass);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ReportForm";
            this.Text = "ReportForm";
            this.Load += new System.EventHandler(this.ReportForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }




        #endregion

        private System.Windows.Forms.ComboBox cbClass;
        private System.Windows.Forms.TextBox txtMaxScore;
        private System.Windows.Forms.TextBox txtTopCount;
        private System.Windows.Forms.TextBox txtMinScore;
        private System.Windows.Forms.Button btnClassStatistics;
        private System.Windows.Forms.Button btnStudentsByClass;
        private System.Windows.Forms.Button btnTopStudents;
        private System.Windows.Forms.Button btnScoreRange;
        private System.Windows.Forms.DataGridView dgvReport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}