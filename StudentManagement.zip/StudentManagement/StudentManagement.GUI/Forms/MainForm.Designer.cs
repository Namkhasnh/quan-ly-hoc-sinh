﻿namespace StudentManagement.GUI
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStudent = new System.Windows.Forms.Button();
            this.btnClass = new System.Windows.Forms.Button();
            this.btnScore = new System.Windows.Forms.Button();
            this.btnSubject = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnStudent
            // 
            this.btnStudent.Location = new System.Drawing.Point(87, 59);
            this.btnStudent.Name = "btnStudent";
            this.btnStudent.Size = new System.Drawing.Size(484, 114);
            this.btnStudent.TabIndex = 0;
            this.btnStudent.Text = "Quan Ly Sinh Vien ";
            this.btnStudent.UseVisualStyleBackColor = true;
            this.btnStudent.Click += new System.EventHandler(this.btnStudent_Click);
            // 
            // btnClass
            // 
            this.btnClass.Location = new System.Drawing.Point(87, 222);
            this.btnClass.Name = "btnClass";
            this.btnClass.Size = new System.Drawing.Size(484, 114);
            this.btnClass.TabIndex = 1;
            this.btnClass.Text = "Quan Ly Lop Hoc";
            this.btnClass.UseVisualStyleBackColor = true;
            this.btnClass.Click += new System.EventHandler(this.btnClass_Click_1);
            // 
            // btnScore
            // 
            this.btnScore.Location = new System.Drawing.Point(87, 548);
            this.btnScore.Name = "btnScore";
            this.btnScore.Size = new System.Drawing.Size(484, 114);
            this.btnScore.TabIndex = 2;
            this.btnScore.Text = "Quan Ly Diem";
            this.btnScore.UseVisualStyleBackColor = true;
            this.btnScore.Click += new System.EventHandler(this.btnScore_Click_1);
            // 
            // btnSubject
            // 
            this.btnSubject.Location = new System.Drawing.Point(87, 385);
            this.btnSubject.Name = "btnSubject";
            this.btnSubject.Size = new System.Drawing.Size(484, 114);
            this.btnSubject.TabIndex = 3;
            this.btnSubject.Text = "Quan Ly Mon Hoc";
            this.btnSubject.UseVisualStyleBackColor = true;
            this.btnSubject.Click += new System.EventHandler(this.btnSubject_Click_1);
            // 
            // btnReport
            // 
            this.btnReport.Location = new System.Drawing.Point(87, 711);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(484, 114);
            this.btnReport.TabIndex = 4;
            this.btnReport.Text = "Thong Ke";
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click_1);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(18F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(647, 900);
            this.Controls.Add(this.btnReport);
            this.Controls.Add(this.btnSubject);
            this.Controls.Add(this.btnScore);
            this.Controls.Add(this.btnClass);
            this.Controls.Add(this.btnStudent);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnStudent;
        private System.Windows.Forms.Button btnClass;
        private System.Windows.Forms.Button btnScore;
        private System.Windows.Forms.Button btnSubject;
        private System.Windows.Forms.Button btnReport;
    }
}

