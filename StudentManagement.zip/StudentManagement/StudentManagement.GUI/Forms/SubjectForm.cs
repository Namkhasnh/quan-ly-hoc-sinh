﻿using System;
using System.Linq;
using System.Windows.Forms;
using StudentManagement.BLL.Services;
using StudentManagement.Entities;

namespace StudentManagement.GUI.Forms
{
    public partial class SubjectForm : Form
    {
        private readonly ISubjectService _subjectService;
        private int _selectedSubjectId = 0;

        public SubjectForm(ISubjectService subjectService)
        {
            InitializeComponent();
            _subjectService = subjectService ?? throw new ArgumentNullException(nameof(subjectService));

            this.Load += SubjectForm_Load;
        }

        private async void SubjectForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.Text = "QUẢN LÝ MÔN HỌC";
                await LoadSubjectsAsync();

                // Gán sự kiện
                btnAdd.Click += BtnAdd_Click;
                btnUpdate.Click += BtnUpdate_Click;
                btnDelete.Click += BtnDelete_Click;
                btnClear.Click += BtnClear_Click;
                dgvSubjects.SelectionChanged += DgvSubjects_SelectionChanged;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tải dữ liệu: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async System.Threading.Tasks.Task LoadSubjectsAsync()
        {
            var subjects = await _subjectService.GetAllSubjectsAsync();

            dgvSubjects.DataSource = subjects.Select(s => new
            {
                s.SubjectId,
                s.SubjectName,
                s.Credit
            }).ToList();

            dgvSubjects.Columns["SubjectId"].HeaderText = "Mã môn";
            dgvSubjects.Columns["SubjectName"].HeaderText = "Tên môn học";
            dgvSubjects.Columns["Credit"].HeaderText = "Số tín chỉ";
        }

        private async void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                var subject = new Subject
                {
                    SubjectName = txtSubjectName.Text.Trim(),
                    Credit = int.Parse(txtCredit.Text.Trim())
                };

                await _subjectService.AddSubjectAsync(subject);
                MessageBox.Show("Thêm môn học thành công!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                await LoadSubjectsAsync();
                ClearInputs();
            }
            catch (FormatException)
            {
                MessageBox.Show("Số tín chỉ phải là số nguyên!", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (_selectedSubjectId == 0)
                {
                    MessageBox.Show("Vui lòng chọn môn học cần cập nhật!", "Cảnh báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var subject = new Subject
                {
                    SubjectId = _selectedSubjectId,
                    SubjectName = txtSubjectName.Text.Trim(),
                    Credit = int.Parse(txtCredit.Text.Trim())
                };

                var result = await _subjectService.UpdateSubjectAsync(subject);
                if (result)
                {
                    MessageBox.Show("Cập nhật môn học thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    await LoadSubjectsAsync();
                    ClearInputs();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Số tín chỉ phải là số nguyên!", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (_selectedSubjectId == 0)
                {
                    MessageBox.Show("Vui lòng chọn môn học cần xóa!", "Cảnh báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var confirm = MessageBox.Show("Bạn có chắc chắn muốn xóa môn học này?",
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    var result = await _subjectService.DeleteSubjectAsync(_selectedSubjectId);
                    if (result)
                    {
                        MessageBox.Show("Xóa môn học thành công!", "Thông báo",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        await LoadSubjectsAsync();
                        ClearInputs();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void DgvSubjects_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSubjects.CurrentRow != null)
            {
                _selectedSubjectId = Convert.ToInt32(dgvSubjects.CurrentRow.Cells["SubjectId"].Value);
                txtSubjectId.Text = _selectedSubjectId.ToString();
                txtSubjectName.Text = dgvSubjects.CurrentRow.Cells["SubjectName"].Value.ToString();
                txtCredit.Text = dgvSubjects.CurrentRow.Cells["Credit"].Value.ToString();
            }
        }

        private void ClearInputs()
        {
            _selectedSubjectId = 0;
            txtSubjectId.Clear();
            txtSubjectName.Clear();
            txtCredit.Clear();
        }
    }
}