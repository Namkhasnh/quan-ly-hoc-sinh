﻿using System;
using System.Windows.Forms;
using Microsoft.Extensions.DependencyInjection;
using StudentManagement.GUI.Forms;


namespace StudentManagement.GUI
{
    public partial class MainForm : Form
    {
        private readonly IServiceProvider _serviceProvider;

        public MainForm(IServiceProvider serviceProvider)
        {
            InitializeComponent();
            _serviceProvider = serviceProvider
                ?? throw new ArgumentNullException(nameof(serviceProvider));

            this.Load += MainForm_Load;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // ❌ KHÔNG gắn Click ở đây nữa
            this.Text = "HỆ THỐNG QUẢN LÝ SINH VIÊN";
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        // ===== CÁC EVENT CLICK (ĐÃ ĐƯỢC DESIGNER GẮN) =====
        private void btnStudent_Click(object sender, EventArgs e)
        {
            var form = _serviceProvider.GetRequiredService<StudentForm>();
            form.ShowDialog();
        }


        private void btnClass_Click_1(object sender, EventArgs e)
        {
            var form = _serviceProvider.GetRequiredService<ClassForm>();
            form.ShowDialog();
        }

        private void btnSubject_Click_1(object sender, EventArgs e)
        {
            var form = _serviceProvider.GetRequiredService<SubjectForm>();
            form.ShowDialog();

        }

        private void btnScore_Click_1(object sender, EventArgs e)
        {
            var form = _serviceProvider.GetRequiredService<ScoreForm>();
            form.ShowDialog();
        }

        private void btnReport_Click_1(object sender, EventArgs e)
        {
            var form = _serviceProvider.GetRequiredService<ReportForm>();
            form.ShowDialog();
        }
    }
}

