﻿using System;
using System.Linq;
using System.Windows.Forms;
using StudentManagement.BLL.Services;
using StudentManagement.Entities;

namespace StudentManagement.GUI.Forms
{
    public partial class ScoreForm : Form
    {
        private readonly IScoreService _scoreService;
        private readonly IStudentService _studentService;
        private readonly ISubjectService _subjectService;
        private int _selectedScoreId = 0;

        public ScoreForm(
            IScoreService scoreService,
            IStudentService studentService,
            ISubjectService subjectService)
        {
            InitializeComponent();
            _scoreService = scoreService ?? throw new ArgumentNullException(nameof(scoreService));
            _studentService = studentService ?? throw new ArgumentNullException(nameof(studentService));
            _subjectService = subjectService ?? throw new ArgumentNullException(nameof(subjectService));

            this.Load += ScoreForm_Load;
        }

        private async void ScoreForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.Text = "QUẢN LÝ ĐIỂM";

                // Load danh sách sinh viên và môn học
                await LoadStudentsAsync();
                await LoadSubjectsAsync();
                await LoadScoresAsync();

                // Gán sự kiện
                btnAdd.Click += BtnAdd_Click;
                btnUpdate.Click += BtnUpdate_Click;
                btnDelete.Click += BtnDelete_Click;
                btnClear.Click += BtnClear_Click;
                btnCalculateAvg.Click += BtnCalculateAvg_Click;
                dgvScores.SelectionChanged += DgvScores_SelectionChanged;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tải dữ liệu: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async System.Threading.Tasks.Task LoadStudentsAsync()
        {
            var students = await _studentService.GetAllStudentsAsync();
            cbStudent.DataSource = students;
            cbStudent.DisplayMember = "StudentName";
            cbStudent.ValueMember = "StudentId";
        }

        private async System.Threading.Tasks.Task LoadSubjectsAsync()
        {
            var subjects = await _subjectService.GetAllSubjectsAsync();
            cbSubject.DataSource = subjects;
            cbSubject.DisplayMember = "SubjectName";
            cbSubject.ValueMember = "SubjectId";
        }

        private async System.Threading.Tasks.Task LoadScoresAsync()
        {
            var scores = await _scoreService.GetAllScoresAsync();

            dgvScores.DataSource = scores.Select(s => new
            {
                s.ScoreId,
                StudentName = s.Student?.StudentName ?? "",
                SubjectName = s.Subject?.SubjectName ?? "",
                s.ScoreValue
            }).ToList();

            dgvScores.Columns["ScoreId"].HeaderText = "Mã điểm";
            dgvScores.Columns["StudentName"].HeaderText = "Sinh viên";
            dgvScores.Columns["SubjectName"].HeaderText = "Môn học";
            dgvScores.Columns["ScoreValue"].HeaderText = "Điểm";
        }

        private async void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                var score = new Score
                {
                    StudentId = (int)cbStudent.SelectedValue,
                    SubjectId = (int)cbSubject.SelectedValue,
                    ScoreValue = decimal.Parse(txtScoreValue.Text.Trim())
                };

                await _scoreService.AddScoreAsync(score);
                MessageBox.Show("Thêm điểm thành công!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                await LoadScoresAsync();
                ClearInputs();
            }
            catch (FormatException)
            {
                MessageBox.Show("Điểm phải là số thập phân!", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (_selectedScoreId == 0)
                {
                    MessageBox.Show("Vui lòng chọn điểm cần cập nhật!", "Cảnh báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var score = new Score
                {
                    ScoreId = _selectedScoreId,
                    StudentId = (int)cbStudent.SelectedValue,
                    SubjectId = (int)cbSubject.SelectedValue,
                    ScoreValue = decimal.Parse(txtScoreValue.Text.Trim())
                };

                var result = await _scoreService.UpdateScoreAsync(score);
                if (result)
                {
                    MessageBox.Show("Cập nhật điểm thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    await LoadScoresAsync();
                    ClearInputs();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Điểm phải là số thập phân!", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (_selectedScoreId == 0)
                {
                    MessageBox.Show("Vui lòng chọn điểm cần xóa!", "Cảnh báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var confirm = MessageBox.Show("Bạn có chắc chắn muốn xóa điểm này?",
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    var result = await _scoreService.DeleteScoreAsync(_selectedScoreId);
                    if (result)
                    {
                        MessageBox.Show("Xóa điểm thành công!", "Thông báo",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        await LoadScoresAsync();
                        ClearInputs();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void BtnCalculateAvg_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbStudent.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn sinh viên!", "Cảnh báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int studentId = (int)cbStudent.SelectedValue;
                decimal avgScore = await _scoreService.GetAverageScoreByStudentAsync(studentId);

                MessageBox.Show($"Điểm trung bình của sinh viên: {avgScore:F2}",
                    "Kết quả", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void DgvScores_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvScores.CurrentRow != null)
            {
                _selectedScoreId = Convert.ToInt32(dgvScores.CurrentRow.Cells["ScoreId"].Value);
                txtScoreId.Text = _selectedScoreId.ToString();

                var studentName = dgvScores.CurrentRow.Cells["StudentName"].Value.ToString();
                var subjectName = dgvScores.CurrentRow.Cells["SubjectName"].Value.ToString();

                cbStudent.SelectedIndex = cbStudent.FindStringExact(studentName);
                cbSubject.SelectedIndex = cbSubject.FindStringExact(subjectName);

                txtScoreValue.Text = dgvScores.CurrentRow.Cells["ScoreValue"].Value.ToString();
            }
        }

        private void ClearInputs()
        {
            _selectedScoreId = 0;
            txtScoreId.Clear();
            txtScoreValue.Clear();
            if (cbStudent.Items.Count > 0) cbStudent.SelectedIndex = 0;
            if (cbSubject.Items.Count > 0) cbSubject.SelectedIndex = 0;
        }
    }
}