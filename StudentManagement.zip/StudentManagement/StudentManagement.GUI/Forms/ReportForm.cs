﻿using System;
using System.Linq;
using System.Windows.Forms;
using StudentManagement.BLL.Services;

namespace StudentManagement.GUI.Forms
{
    public partial class ReportForm : Form
    {
        private readonly IReportService _reportService;
        private readonly IClassService _classService;

        public ReportForm(IReportService reportService, IClassService classService)
        {
            InitializeComponent();
            _reportService = reportService ?? throw new ArgumentNullException(nameof(reportService));
            _classService = classService ?? throw new ArgumentNullException(nameof(classService));

            this.Load += ReportForm_Load;
        }

        private async void ReportForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.Text = "BÁO CÁO & THỐNG KÊ";

                // Load danh sách lớp
                var classes = await _classService.GetAllClassesAsync();
                cbClass.DataSource = classes;
                cbClass.DisplayMember = "ClassName";
                cbClass.ValueMember = "ClassId";

                // Gán sự kiện
                btnClassStatistics.Click += BtnClassStatistics_Click;
                btnStudentsByClass.Click += BtnStudentsByClass_Click;
                btnTopStudents.Click += BtnTopStudents_Click;
                btnScoreRange.Click += BtnScoreRange_Click;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tải dữ liệu: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // THỐNG KÊ THEO LỚP
        private async void BtnClassStatistics_Click(object sender, EventArgs e)
        {
            try
            {
                var statistics = await _reportService.GetClassStatisticsAsync();

                dgvReport.DataSource = statistics.Select(s => new
                {
                    MaLop = s.ClassId,
                    TenLop = s.ClassName,
                    SoSinhVien = s.TotalStudents,
                    DiemTrungBinh = s.AverageScore
                }).ToList();

                dgvReport.Columns["MaLop"].HeaderText = "Mã lớp";
                dgvReport.Columns["TenLop"].HeaderText = "Tên lớp";
                dgvReport.Columns["SoSinhVien"].HeaderText = "Số sinh viên";
                dgvReport.Columns["DiemTrungBinh"].HeaderText = "Điểm TB";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // SINH VIÊN THEO LỚP
        private async void BtnStudentsByClass_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbClass.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn lớp!", "Cảnh báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int classId = (int)cbClass.SelectedValue;
                var students = await _reportService.GetStudentReportByClassAsync(classId);

                dgvReport.DataSource = students.Select(s => new
                {
                    MaSV = s.StudentId,
                    HoTen = s.StudentName,
                    Lop = s.ClassName,
                    DiemTB = s.AverageScore,
                    SoMon = s.TotalSubjects,
                    XepLoai = s.Rank
                }).ToList();

                dgvReport.Columns["MaSV"].HeaderText = "Mã SV";
                dgvReport.Columns["HoTen"].HeaderText = "Họ tên";
                dgvReport.Columns["Lop"].HeaderText = "Lớp";
                dgvReport.Columns["DiemTB"].HeaderText = "Điểm TB";
                dgvReport.Columns["SoMon"].HeaderText = "Số môn";
                dgvReport.Columns["XepLoai"].HeaderText = "Xếp loại";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // TOP SINH VIÊN GIỎI
        private async void BtnTopStudents_Click(object sender, EventArgs e)
        {
            try
            {
                int topCount = string.IsNullOrWhiteSpace(txtTopCount.Text) ? 10 : int.Parse(txtTopCount.Text);
                var topStudents = await _reportService.GetTopStudentsAsync(topCount);

                dgvReport.DataSource = topStudents.Select((s, index) => new
                {
                    STT = index + 1,
                    MaSV = s.StudentId,
                    HoTen = s.StudentName,
                    Lop = s.ClassName,
                    DiemTB = s.AverageScore,
                    SoMon = s.TotalSubjects,
                    XepLoai = s.Rank
                }).ToList();

                dgvReport.Columns["STT"].HeaderText = "STT";
                dgvReport.Columns["MaSV"].HeaderText = "Mã SV";
                dgvReport.Columns["HoTen"].HeaderText = "Họ tên";
                dgvReport.Columns["Lop"].HeaderText = "Lớp";
                dgvReport.Columns["DiemTB"].HeaderText = "Điểm TB";
                dgvReport.Columns["SoMon"].HeaderText = "Số môn";
                dgvReport.Columns["XepLoai"].HeaderText = "Xếp loại";
            }
            catch (FormatException)
            {
                MessageBox.Show("Số lượng phải là số nguyên!", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // SINH VIÊN THEO KHOẢNG ĐIỂM
        private async void BtnScoreRange_Click(object sender, EventArgs e)
        {
            try
            {
                decimal minScore = decimal.Parse(txtMinScore.Text.Trim());
                decimal maxScore = decimal.Parse(txtMaxScore.Text.Trim());

                var students = await _reportService.GetStudentsByAverageScoreRangeAsync(minScore, maxScore);

                dgvReport.DataSource = students.Select(s => new
                {
                    MaSV = s.StudentId,
                    HoTen = s.StudentName,
                    Lop = s.ClassName,
                    DiemTB = s.AverageScore,
                    SoMon = s.TotalSubjects,
                    XepLoai = s.Rank
                }).ToList();

                dgvReport.Columns["MaSV"].HeaderText = "Mã SV";
                dgvReport.Columns["HoTen"].HeaderText = "Họ tên";
                dgvReport.Columns["Lop"].HeaderText = "Lớp";
                dgvReport.Columns["DiemTB"].HeaderText = "Điểm TB";
                dgvReport.Columns["SoMon"].HeaderText = "Số môn";
                dgvReport.Columns["XepLoai"].HeaderText = "Xếp loại";
            }
            catch (FormatException)
            {
                MessageBox.Show("Điểm phải là số thập phân!", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}