﻿using System;
using System.Linq;
using System.Windows.Forms;
using StudentManagement.BLL.Services;
using StudentManagement.Entities;


namespace StudentManagement.GUI
{
    public partial class ClassForm : Form
    {
        private readonly IClassService _classService;
        private int _selectedClassId = 0;

        public ClassForm(IClassService classService)
        {
            InitializeComponent();
            _classService = classService ?? throw new ArgumentNullException(nameof(classService));

            this.Load += ClassForm_Load;
        }

        private async void ClassForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.Text = "QUẢN LÝ LỚP HỌC";

                dgvClasses.SelectionChanged += DgvClasses_SelectionChanged;
                dgvClasses.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgvClasses.MultiSelect = false;

                await LoadClassesAsync();

                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tải dữ liệu: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async System.Threading.Tasks.Task LoadClassesAsync()
        {
            var classes = await _classService.GetAllClassesAsync();

            dgvClasses.DataSource = classes.Select(c => new
            {
                c.ClassId,
                c.ClassName,
                c.Description,
                TotalStudents = c.Students?.Count ?? 0
            }).ToList();

            dgvClasses.Columns["ClassId"].HeaderText = "Mã lớp";
            dgvClasses.Columns["ClassName"].HeaderText = "Tên lớp";
            dgvClasses.Columns["Description"].HeaderText = "Mô tả";
            dgvClasses.Columns["TotalStudents"].HeaderText = "Số SV";
        }

        private async void BtnAdd_Click_1(object sender, EventArgs e)
        {
            try
            {
                var classEntity = new Class
                {
                    ClassName = txtClassName.Text.Trim(),
                    Description = txtDescription.Text.Trim()
                };

                await _classService.AddClassAsync(classEntity);
                MessageBox.Show("Thêm lớp học thành công!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                await LoadClassesAsync();
                ClearInputs();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (_selectedClassId == 0)
                {
                    MessageBox.Show("Vui lòng chọn lớp cần cập nhật!", "Cảnh báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var classEntity = new Class
                {
                    ClassId = _selectedClassId,
                    ClassName = txtClassName.Text.Trim(),
                    Description = txtDescription.Text.Trim()
                };

                var result = await _classService.UpdateClassAsync(classEntity);
                if (result)
                {
                    MessageBox.Show("Cập nhật lớp học thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    await LoadClassesAsync();
                    ClearInputs();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (_selectedClassId == 0)
                {
                    MessageBox.Show("Vui lòng chọn lớp cần xóa!", "Cảnh báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var confirm = MessageBox.Show("Bạn có chắc chắn muốn xóa lớp này?",
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    var result = await _classService.DeleteClassAsync(_selectedClassId);
                    if (result)
                    {
                        MessageBox.Show("Xóa lớp học thành công!", "Thông báo",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        await LoadClassesAsync();
                        ClearInputs();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void DgvClasses_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvClasses.CurrentRow != null)
            {
                _selectedClassId = Convert.ToInt32(dgvClasses.CurrentRow.Cells["ClassId"].Value);
                txtClassId.Text = _selectedClassId.ToString();
                txtClassName.Text = dgvClasses.CurrentRow.Cells["ClassName"].Value.ToString();
                txtDescription.Text = dgvClasses.CurrentRow.Cells["Description"].Value?.ToString() ?? "";
            }
        }

        private void ClearInputs()
        {
            _selectedClassId = 0;
            txtClassId.Clear();
            txtClassName.Clear();
            txtDescription.Clear();
        }

        
    }
}