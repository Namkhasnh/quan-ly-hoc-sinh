﻿using System;
using System.Linq;
using System.Windows.Forms;
using StudentManagement.BLL.Services;
using StudentManagement.Entities;

namespace StudentManagement.GUI
{
    public partial class StudentForm : Form
    {
        private readonly IStudentService _studentService;
        private readonly IClassService _classService;
        private int _selectedStudentId = 0;

        public StudentForm(IStudentService studentService, IClassService classService)
        {
            InitializeComponent();
            _studentService = studentService ?? throw new ArgumentNullException(nameof(studentService));
            _classService = classService ?? throw new ArgumentNullException(nameof(classService));

            this.Load += StudentForm_Load;
        }

        private async void StudentForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.Text = "QUẢN LÝ SINH VIÊN";

                // 🔥 GÁN EVENT Ở ĐÂY
                dgvStudents.SelectionChanged += DgvStudents_SelectionChanged;
                dgvStudents.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgvStudents.MultiSelect = false;

                await LoadClassesAsync();
                await LoadStudentsAsync();

                cbGender.Items.Clear();
                cbGender.Items.Add("Nam");
                cbGender.Items.Add("Nữ");
                cbGender.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Lỗi");
            }
        }



        private async System.Threading.Tasks.Task LoadClassesAsync()
        {
            var classes = await _classService.GetAllClassesAsync();
            cbClass.DataSource = classes;
            cbClass.DisplayMember = "ClassName";
            cbClass.ValueMember = "ClassId";
        }

        private async System.Threading.Tasks.Task LoadStudentsAsync()
        {
            var students = await _studentService.GetAllStudentsAsync();

            dgvStudents.DataSource = students.Select(s => new
            {
                s.StudentId,
                StudentName = s.StudentName,
                DateOfBirth = s.DateOfBirth.ToString("dd/MM/yyyy"),
                s.Gender,
                ClassName = s.Class?.ClassName ?? ""
            }).ToList();

            dgvStudents.Columns["StudentId"].HeaderText = "Mã SV";
            dgvStudents.Columns["StudentName"].HeaderText = "Họ tên";
            dgvStudents.Columns["DateOfBirth"].HeaderText = "Ngày sinh";
            dgvStudents.Columns["Gender"].HeaderText = "Giới tính";
            dgvStudents.Columns["ClassName"].HeaderText = "Lớp";
        }

        private async void btnAdd_Click_1(object sender, EventArgs e)
        {
            try
            {
                var student = new Student
                {
                    StudentName = txtStudentName.Text.Trim(),
                    DateOfBirth = dtpDateOfBirth.Value,
                    Gender = cbGender.SelectedItem?.ToString() ?? "Nam",
                    ClassId = (int)cbClass.SelectedValue
                };

                await _studentService.AddStudentAsync(student);
                MessageBox.Show("Thêm sinh viên thành công!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                await LoadStudentsAsync();
                ClearInputs();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnUpdate_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (_selectedStudentId == 0)
                {
                    MessageBox.Show("Vui lòng chọn sinh viên cần cập nhật!", "Cảnh báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var student = new Student
                {
                    StudentId = _selectedStudentId,
                    StudentName = txtStudentName.Text.Trim(),
                    DateOfBirth = dtpDateOfBirth.Value,
                    Gender = cbGender.SelectedItem?.ToString() ?? "Nam",
                    ClassId = (int)cbClass.SelectedValue
                };

                var result = await _studentService.UpdateStudentAsync(student);
                if (result)
                {
                    MessageBox.Show("Cập nhật sinh viên thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    await LoadStudentsAsync();
                    ClearInputs();
                }
                else
                {
                    MessageBox.Show("Không tìm thấy sinh viên!", "Lỗi",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnDelete_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (_selectedStudentId == 0)
                {
                    MessageBox.Show("Vui lòng chọn sinh viên cần xóa!", "Cảnh báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var confirm = MessageBox.Show("Bạn có chắc chắn muốn xóa sinh viên này?",
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    var result = await _studentService.DeleteStudentAsync(_selectedStudentId);
                    if (result)
                    {
                        MessageBox.Show("Xóa sinh viên thành công!", "Thông báo",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        await LoadStudentsAsync();
                        ClearInputs();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnSearch_Click_1(object sender, EventArgs e)
        {
            try
            {
                var keyword = txtSearchStudent.Text.Trim();
                var students = await _studentService.SearchStudentsByNameAsync(keyword);

                dgvStudents.DataSource = students.Select(s => new
                {
                    s.StudentId,
                    StudentName = s.StudentName,
                    DateOfBirth = s.DateOfBirth.ToString("dd/MM/yyyy"),
                    s.Gender,
                    ClassName = s.Class?.ClassName ?? ""
                }).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click_1(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void DgvStudents_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvStudents.CurrentRow != null)
            {
                _selectedStudentId = Convert.ToInt32(dgvStudents.CurrentRow.Cells["StudentId"].Value);
                txtStudentId.Text = _selectedStudentId.ToString();
                txtStudentName.Text = dgvStudents.CurrentRow.Cells["StudentName"].Value.ToString();
                dtpDateOfBirth.Value = DateTime.ParseExact(
                    dgvStudents.CurrentRow.Cells["DateOfBirth"].Value.ToString(),
                    "dd/MM/yyyy", null);
                cbGender.SelectedItem = dgvStudents.CurrentRow.Cells["Gender"].Value.ToString();

                var className = dgvStudents.CurrentRow.Cells["ClassName"].Value.ToString();
                cbClass.SelectedIndex = cbClass.FindStringExact(className);
            }
        }

        private void ClearInputs()
        {
            _selectedStudentId = 0;
            txtStudentId.Clear();
            txtStudentName.Clear();
            txtSearchStudent.Clear();
            dtpDateOfBirth.Value = DateTime.Now.AddYears(-18);
            cbGender.SelectedIndex = 0;
            if (cbClass.Items.Count > 0)
                cbClass.SelectedIndex = 0;
        }

        private void dgvStudents_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cbGender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtStudentId_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}