﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StudentManagement.Entities
{
    [Table("Subjects")]
    public class Subject
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SubjectId { get; set; }

        [Required]
        [StringLength(200)]
        public string SubjectName { get; set; }

        [Required]
        public int Credit { get; set; }

        // Navigation Property
        public virtual ICollection<Score> Scores { get; set; }

        public Subject()
        {
            Scores = new HashSet<Score>();
        }
    }
}