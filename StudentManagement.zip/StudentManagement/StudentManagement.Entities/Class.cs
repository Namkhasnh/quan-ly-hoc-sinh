﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StudentManagement.Entities
{
    [Table("Classes")]
    public class Class
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ClassId { get; set; }

        [Required]
        [StringLength(100)]
        public string ClassName { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        // Navigation Property
        public virtual ICollection<Student> Students { get; set; }

        public Class()
        {
            Students = new HashSet<Student>();
        }
    }
}